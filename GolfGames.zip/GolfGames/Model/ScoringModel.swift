//
//  ScoringModel.swift
//  GolfGames
//
//  Created by Mike Dietrich on 7/6/24.
//

import Foundation
